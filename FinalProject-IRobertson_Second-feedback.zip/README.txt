Quick notes about my project.

I still need to touch up on some stuff and finish up the pages functionality before polishing them but
I made a lot of progress on them. the runner page I might see if I want to calculate the VO2 max
if the calculation isn't too bad and I also am almost done with the game page. the game page just needs a score
and a "death" function and It will be complete after that. It doesn't look pretty right now but I just been focusing on funcionality
first before the final polish up stage for it.